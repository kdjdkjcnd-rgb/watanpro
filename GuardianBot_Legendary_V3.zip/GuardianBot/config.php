<?php

/**
 * Telegram Guardian Bot Configuration
 */

return [
    'bot_token' => 'YOUR_BOT_TOKEN_HERE', // استبدل بـ توكن البوت الخاص بك
    'developer_id' => 'YOUR_TELEGRAM_ID_HERE', // استبدل بـ آيدي المطور
    
    'database' => [
        'type' => 'sqlite', // خيارات: sqlite, mysql
        'sqlite_path' => __DIR__ . '/storage/database.sqlite',
        'mysql' => [
            'host' => 'localhost',
            'dbname' => 'guardian_bot',
            'username' => 'root',
            'password' => '',
        ],
    ],
    
    'settings' => [
        'max_warnings' => 3,
        'anti_spam_limit' => 5, // عدد الرسائل في الثانية
        'log_channel' => null, // آيدي قناة السجل (اختياري)
    ],
];
