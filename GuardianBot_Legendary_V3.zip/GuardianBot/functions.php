<?php

/**
 * Global functions for Guardian Bot
 */

function get_config($key, $default = null) {
    static $config;
    if (!$config) {
        $config = require __DIR__ . '/config.php';
    }
    
    $keys = explode('.', $key);
    $value = $config;
    
    foreach ($keys as $k) {
        if (isset($value[$k])) {
            $value = $value[$k];
        } else {
            return $default;
        }
    }
    
    return $value;
}
