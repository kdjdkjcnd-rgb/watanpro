<?php

/**
 * Points Handler - Handles points system commands
 */

function handlePoints($bot, $update, $db) {
    if (!isset($update['message'])) return;

    $message = $update['message'];
    $chatId = $message['chat']['id'];
    $userId = $message['from']['id'];
    $text = $message['text'] ?? '';

    // أمر "نقاطي"
    if ($text === 'نقاطي') {
        $userData = $db->fetch("SELECT points FROM users WHERE id = ?", [$userId]);
        $points = $userData['points'] ?? 0;
        $bot->sendMessage($chatId, "⭐ عدد نقاطك الحالي هو: <b>{$points}</b>");
        return true;
    }

    // أمر "تحويل" (بالرد)
    if (preg_match('/^تحويل (\d+)$/u', $text, $matches) && isset($message['reply_to_message'])) {
        $amount = (int)$matches[1];
        $targetId = $message['reply_to_message']['from']['id'];

        // خصم من المرسل
        $senderData = $db->fetch("SELECT points FROM users WHERE id = ?", [$userId]);
        if (($senderData['points'] ?? 0) < $amount) {
            $bot->sendMessage($chatId, "⚠️ عذراً، نقاطك غير كافية لإتمام التحويل.");
            return true;
        }

        $db->query("UPDATE users SET points = points - ? WHERE id = ?", [$amount, $userId]);
        $db->query("UPDATE users SET points = points + ? WHERE id = ?", [$amount, $targetId]);

        $bot->sendMessage($chatId, "✅ تم تحويل <b>{$amount}</b> نقطة بنجاح.");
        return true;
    }

    return false;
}
