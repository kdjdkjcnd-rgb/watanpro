<?php

/**
 * Admin Handler - Handles administrative commands like ban, mute, kick
 */

function handleAdminCommands($bot, $update, $userRank) {
    if (!isset($update['message'])) return;

    $message = $update['message'];
    $chatId = $message['chat']['id'];
    $text = $message['text'] ?? '';
    
    // التحقق من الصلاحيات (يجب أن يكون مدير أو مطور)
    if (!in_array($userRank, ['creator', 'administrator', 'developer'])) {
        return false;
    }

    // أمر الحظر
    if (preg_match('/^حظر$/u', $text) && isset($message['reply_to_message'])) {
        $targetId = $message['reply_to_message']['from']['id'];
        $targetName = $message['reply_to_message']['from']['first_name'];
        $bot->makeRequest('kickChatMember', ['chat_id' => $chatId, 'user_id' => $targetId]);
        
        $options = [
            'reply_markup' => json_encode([
                'inline_keyboard' => [[['text' => '🔓 إلغاء الحظر', 'callback_data' => "unban_{$targetId}"]]]
            ])
        ];
        $bot->sendMessage($chatId, "🚫 تم حظر المستخدم <b>{$targetName}</b> بنجاح.", $options);
        return true;
    }

    // أمر الكتم
    if (preg_match('/^كتم$/u', $text) && isset($message['reply_to_message'])) {
        $targetId = $message['reply_to_message']['from']['id'];
        $targetName = $message['reply_to_message']['from']['first_name'];
        $bot->makeRequest('restrictChatMember', [
            'chat_id' => $chatId, 
            'user_id' => $targetId,
            'permissions' => json_encode(['can_send_messages' => false])
        ]);

        $options = [
            'reply_markup' => json_encode([
                'inline_keyboard' => [[['text' => '🔊 إلغاء الكتم', 'callback_data' => "unmute_{$targetId}"]]]
            ])
        ];
        $bot->sendMessage($chatId, "🔇 تم كتم المستخدم <b>{$targetName}</b> بنجاح.", $options);
        return true;
    }

    // أوامر القفل والفتح
    if (preg_match('/^قفل الروابط$/u', $text)) {
        // تحديث الإعدادات في قاعدة البيانات (سيتم ربطها لاحقاً)
        $bot->sendMessage($chatId, "🔒 تم قفل الروابط بنجاح.");
        return true;
    }

    return false;
}
