<?php

/**
 * Logs Handler - Handles event logging
 */

function logEvent($db, $groupId, $userId, $action, $details = "") {
    $db->query("INSERT INTO logs (group_id, user_id, action, details) VALUES (?, ?, ?, ?)", [
        $groupId, $userId, $action, $details
    ]);
}

function getRecentLogs($db, $groupId, $limit = 10) {
    return $db->fetchAll("SELECT * FROM logs WHERE group_id = ? ORDER BY created_at DESC LIMIT ?", [
        $groupId, $limit
    ]);
}
