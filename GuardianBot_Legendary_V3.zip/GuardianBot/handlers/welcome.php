<?php

/**
 * Welcome Handler - Handles new members and welcome messages
 */

function handleWelcome($bot, $update) {
    if (!isset($update['message']['new_chat_members'])) return;

    $chatId = $update['message']['chat']['id'];
    $chatTitle = $update['message']['chat']['title'];
    
    foreach ($update['message']['new_chat_members'] as $member) {
        $name = $member['first_name'];
        $id = $member['id'];
        $username = isset($member['username']) ? "@" . $member['username'] : "لا يوجد";
        
        $welcomeText = "━━━━━━━━━━━━━━\n";
        $welcomeText .= "🎉 أهلاً بك في مجموعة {$chatTitle}\n\n";
        $welcomeText .= "👤 الاسم: <b>{$name}</b>\n";
        $welcomeText .= "🆔 الآيدي: <code>{$id}</code>\n";
        $welcomeText .= "📎 اليوزر: {$username}\n";
        $welcomeText .= "━━━━━━━━━━━━━━";

        $options = [
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '📜 القوانين', 'callback_data' => 'rules'],
                        ['text' => '👨‍💻 المطور', 'url' => 'https://t.me/GuardianDev']
                    ]
                ]
            ])
        ];

        $bot->sendMessage($chatId, $welcomeText, $options);
    }
}
