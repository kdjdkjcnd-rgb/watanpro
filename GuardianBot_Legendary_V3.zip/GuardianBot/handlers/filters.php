<?php

/**
 * Filters Handler - Handles message filtering and protection
 */

function handleFilters($bot, $update, $groupSettings) {
    if (!isset($update['message'])) return;

    $message = $update['message'];
    $chatId = $message['chat']['id'];
    $messageId = $message['message_id'];
    $text = $message['text'] ?? '';
    $entities = $message['entities'] ?? [];

    // 1. فحص الروابط
    if ($groupSettings['lock_links'] && hasLink($text, $entities)) {
        $bot->deleteMessage($chatId, $messageId);
        return true;
    }

    // 2. فحص المعرفات (@)
    if ($groupSettings['lock_user'] && strpos($text, '@') !== false) {
        $bot->deleteMessage($chatId, $messageId);
        return true;
    }

    // 3. فحص الصور
    if ($groupSettings['lock_photos'] && isset($message['photo'])) {
        $bot->deleteMessage($chatId, $messageId);
        return true;
    }

    // 4. فحص السب والشتم (تبسيط)
    $badWords = ['كلب', 'حمار', 'غبي']; // قائمة تجريبية
    foreach ($badWords as $word) {
        if (strpos($text, $word) !== false) {
            $bot->deleteMessage($chatId, $messageId);
            return true;
        }
    }

    return false;
}

function hasLink($text, $entities) {
    foreach ($entities as $entity) {
        if ($entity['type'] === 'url' || $entity['type'] === 'text_link') {
            return true;
        }
    }
    return false;
}
