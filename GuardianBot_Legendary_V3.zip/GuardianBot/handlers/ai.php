<?php

/**
 * AI Handler - Simple text analysis for spam and offensive content
 */

function analyzeContent($text) {
    // محاكاة للذكاء الاصطناعي عبر فحص الأنماط
    $offensivePatterns = [
        '/(إباحي|سكس|نيك)/iu',
        '/(سب|شتم|لعن)/iu'
    ];

    foreach ($offensivePatterns as $pattern) {
        if (preg_match($pattern, $text)) {
            return ['status' => 'offensive', 'reason' => 'محتوى غير لائق'];
        }
    }

    // فحص التكرار (Spam)
    if (strlen($text) > 500 && substr_count($text, "\n") > 10) {
        return ['status' => 'spam', 'reason' => 'رسالة طويلة جداً'];
    }

    return ['status' => 'safe'];
}
