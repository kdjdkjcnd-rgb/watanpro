<?php

/**
 * Control Panel Handler - Inline settings management
 */

function handleControlPanel($bot, $update, $db, $rank) {
    if (!isset($update['message']) && !isset($update['callback_query'])) return false;

    $chatId = $update['message']['chat']['id'] ?? $update['callback_query']['message']['chat']['id'];
    $text = $update['message']['text'] ?? '';

    // التحقق من الصلاحيات
    if (!in_array($rank, ['creator', 'administrator', 'developer'])) return false;

    if ($text === 'الإعدادات' || $text === '/settings') {
        sendSettingsMain($bot, $chatId, $db);
        return true;
    }

    if (isset($update['callback_query'])) {
        $callback = $update['callback_query'];
        $data = $callback['data'];

        if (strpos($data, 'set_') === 0) {
            $parts = explode('_', $data);
            $key = $parts[1]; // e.g., links
            $currentValue = $parts[2]; // e.g., on/off
            
            $newValue = ($currentValue === 'on') ? 0 : 1;
            $group = new Group($db, $chatId);
            $group->updateSetting("lock_{$key}", $newValue);
            
            updateSettingsMain($bot, $chatId, $callback['message']['message_id'], $db);
            return true;
        }
    }

    return false;
}

function sendSettingsMain($bot, $chatId, $db) {
    $group = new Group($db, $chatId);
    $s = $group->getSettings();

    $text = "⚙️ <b>لوحة تحكم المجموعة</b>\n\n";
    $text .= "تحكم في إعدادات الحماية والمنع من هنا:";

    $buttons = [
        [
            ['text' => ($s['lock_links'] ? "✅ الروابط: مقفل" : "❌ الروابط: مفتوح"), 'callback_data' => "set_links_" . ($s['lock_links'] ? "on" : "off")],
            ['text' => ($s['lock_photos'] ? "✅ الصور: مقفل" : "❌ الصور: مفتوح"), 'callback_data' => "set_photos_" . ($s['lock_photos'] ? "on" : "off")]
        ],
        [
            ['text' => ($s['lock_spam'] ? "✅ الفلود: مقفل" : "❌ الفلود: مفتوح"), 'callback_data' => "set_spam_" . ($s['lock_spam'] ? "on" : "off")],
            ['text' => "📊 الإحصائيات", 'callback_data' => "stats"]
        ]
    ];

    $bot->sendMessage($chatId, $text, ['reply_markup' => json_encode(['inline_keyboard' => $buttons])]);
}

function updateSettingsMain($bot, $chatId, $messageId, $db) {
    $group = new Group($db, $chatId);
    $s = $group->getSettings();

    $text = "⚙️ <b>لوحة تحكم المجموعة</b>\n\n";
    $text .= "تحكم في إعدادات الحماية والمنع من هنا:";

    $buttons = [
        [
            ['text' => ($s['lock_links'] ? "✅ الروابط: مقفل" : "❌ الروابط: مفتوح"), 'callback_data' => "set_links_" . ($s['lock_links'] ? "on" : "off")],
            ['text' => ($s['lock_photos'] ? "✅ الصور: مقفل" : "❌ الصور: مفتوح"), 'callback_data' => "set_photos_" . ($s['lock_photos'] ? "on" : "off")]
        ],
        [
            ['text' => ($s['lock_spam'] ? "✅ الفلود: مقفل" : "❌ الفلود: مفتوح"), 'callback_data' => "set_spam_" . ($s['lock_spam'] ? "on" : "off")],
            ['text' => "📊 الإحصائيات", 'callback_data' => "stats"]
        ]
    ];

    $bot->makeRequest('editMessageText', [
        'chat_id' => $chatId,
        'message_id' => $messageId,
        'text' => $text,
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode(['inline_keyboard' => $buttons])
    ]);
}
