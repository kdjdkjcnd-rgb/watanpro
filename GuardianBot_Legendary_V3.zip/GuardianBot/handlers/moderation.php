<?php

/**
 * Advanced Moderation Handler
 */

function handleCaptchaCallback($bot, $update, $db) {
    if (!isset($update['callback_query'])) return false;

    $callback = $update['callback_query'];
    $data = $callback['data'];
    $userId = $callback['from']['id'];
    $chatId = $callback['message']['chat']['id'];

    if (strpos($data, 'captcha_') === 0) {
        $parts = explode('_', $data);
        $targetUserId = (int)$parts[1];
        $userAnswer = (int)$parts[2];

        if ($userId !== $targetUserId) {
            $bot->makeRequest('answerCallbackQuery', [
                'callback_query_id' => $callback['id'],
                'text' => "⚠️ هذا التحقق ليس لك!",
                'show_alert' => true
            ]);
            return true;
        }

        $captchaData = $db->fetch("SELECT answer, message_id FROM captcha WHERE user_id = ? AND group_id = ?", [
            $userId, $chatId
        ]);

        if ($captchaData && (int)$captchaData['answer'] === $userAnswer) {
            $bot->deleteMessage($chatId, $captchaData['message_id']);
            $bot->makeRequest('answerCallbackQuery', [
                'callback_query_id' => $callback['id'],
                'text' => "✅ تم التحقق بنجاح، أهلاً بك!",
                'show_alert' => false
            ]);
            $db->query("DELETE FROM captcha WHERE user_id = ? AND group_id = ?", [$userId, $chatId]);
            
            // فك التقييد إذا كان مقيداً
            $bot->makeRequest('restrictChatMember', [
                'chat_id' => $chatId,
                'user_id' => $userId,
                'permissions' => json_encode([
                    'can_send_messages' => true,
                    'can_send_media_messages' => true,
                    'can_send_other_messages' => true,
                    'can_add_web_page_previews' => true
                ])
            ]);
        } else {
            $bot->makeRequest('answerCallbackQuery', [
                'callback_query_id' => $callback['id'],
                'text' => "❌ إجابة خاطئة، حاول مجدداً!",
                'show_alert' => true
            ]);
        }
        return true;
    }
    return false;
}

function handleAdminCallbacks($bot, $update, $db, $rank) {
    if (!isset($update['callback_query'])) return false;

    $callback = $update['callback_query'];
    $data = $callback['data'];
    $userId = $callback['from']['id'];
    $chatId = $callback['message']['chat']['id'];

    // التحقق من أن المستخدم هو المالك أو المطور أو مدير
    if (strpos($data, 'unban_') === 0 || strpos($data, 'unmute_') === 0) {
        if (!in_array($rank, ['creator', 'developer'])) {
            $bot->makeRequest('answerCallbackQuery', [
                'callback_query_id' => $callback['id'],
                'text' => "⚠️ عذراً، هذا الزر مخصص لمالك المجموعة أو المطور فقط!",
                'show_alert' => true
            ]);
            return true;
        }

        $parts = explode('_', $data);
        $action = $parts[0];
        $targetId = (int)$parts[1];

        if ($action === 'unban') {
            $bot->makeRequest('unbanChatMember', ['chat_id' => $chatId, 'user_id' => $targetId]);
            $bot->makeRequest('editMessageText', [
                'chat_id' => $chatId,
                'message_id' => $callback['message']['message_id'],
                'text' => "✅ تم إلغاء حظر المستخدم بواسطة المالك."
            ]);
        } elseif ($action === 'unmute') {
            $bot->makeRequest('restrictChatMember', [
                'chat_id' => $chatId,
                'user_id' => $targetId,
                'permissions' => json_encode([
                    'can_send_messages' => true,
                    'can_send_media_messages' => true,
                    'can_send_other_messages' => true,
                    'can_add_web_page_previews' => true
                ])
            ]);
            $bot->makeRequest('editMessageText', [
                'chat_id' => $chatId,
                'message_id' => $callback['message']['message_id'],
                'text' => "✅ تم إلغاء كتم المستخدم بواسطة المالك."
            ]);
        }

        $bot->makeRequest('answerCallbackQuery', [
            'callback_query_id' => $callback['id'],
            'text' => "تم تنفيذ العملية بنجاح."
        ]);
        return true;
    }

    return false;
}
