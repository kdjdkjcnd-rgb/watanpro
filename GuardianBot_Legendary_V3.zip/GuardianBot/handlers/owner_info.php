<?php

/**
 * Owner Info Handler - Shows owner card with profile photo
 */

function handleOwnerInfo($bot, $update) {
    if (!isset($update['message'])) return false;

    $message = $update['message'];
    $chatId = $message['chat']['id'];
    $text = $message['text'] ?? '';

    if ($text === 'المالك') {
        // جلب قائمة المديرين للعثور على المالك
        $admins = $bot->makeRequest('getChatAdministrators', ['chat_id' => $chatId]);
        
        $owner = null;
        if (isset($admins['result'])) {
            foreach ($admins['result'] as $admin) {
                if ($admin['status'] === 'creator') {
                    $owner = $admin['user'];
                    break;
                }
            }
        }

        if ($owner) {
            $ownerId = $owner['id'];
            $name = $owner['first_name'];
            $username = isset($owner['username']) ? "@" . $owner['username'] : "لا يوجد";
            
            // جلب صور الملف الشخصي
            $photos = $bot->makeRequest('getUserProfilePhotos', ['user_id' => $ownerId, 'limit' => 1]);
            
            $caption = "👑 <b>معلومات مالك المجموعة</b>\n\n";
            $caption .= "👤 الاسم: <b>{$name}</b>\n";
            $caption .= "🆔 الآيدي: <code>{$ownerId}</code>\n";
            $caption .= "📎 اليوزر: {$username}\n\n";
            $caption .= "🛡️ الرتبة: مالك المجموعة الأساسي";

            if (isset($photos['result']['photos'][0][0]['file_id'])) {
                $photoId = $photos['result']['photos'][0][0]['file_id'];
                $bot->sendPhoto($chatId, $photoId, $caption);
            } else {
                $bot->sendMessage($chatId, $caption);
            }
            return true;
        } else {
            $bot->sendMessage($chatId, "⚠️ تعذر العثور على مالك المجموعة (قد تكون مجموعة خاصة أو لم يتم تعيين منشئ).");
            return true;
        }
    }

    return false;
}
