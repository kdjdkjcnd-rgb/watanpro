<?php

class Security {
    private $db;
    private $cachePath;

    public function __construct($db) {
        $this->db = $db;
        $this->cachePath = __DIR__ . '/../cache/flood_';
    }

    /**
     * مكافحة الفلود (Anti-Flood)
     */
    public function isFlooding($userId, $limit = 5, $timeframe = 3) {
        $file = $this->cachePath . $userId;
        $now = time();
        
        $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
        
        // تنظيف البيانات القديمة
        $data = array_filter($data, function($timestamp) use ($now, $timeframe) {
            return ($now - $timestamp) < $timeframe;
        });
        
        $data[] = $now;
        file_put_contents($file, json_encode($data));
        
        return count($data) > $limit;
    }

    /**
     * نظام الكابتشا (Captcha)
     */
    public function generateCaptcha($bot, $chatId, $userId, $name) {
        $num1 = rand(1, 10);
        $num2 = rand(1, 10);
        $answer = $num1 + $num2;
        
        $text = "🛡️ <b>نظام التحقق البشري</b>\n\n";
        $text .= "مرحباً {$name}، لمنع البوتات يرجى حل المسألة التالية:\n";
        $text .= "كم ناتج: <b>{$num1} + {$num2} = ؟</b>\n\n";
        $text .= "⚠️ لديك 60 ثانية للحل أو سيتم طردك.";

        // أزرار عشوائية للحل
        $buttons = [];
        $correctIndex = rand(0, 3);
        for ($i = 0; $i < 4; $i++) {
            $val = ($i === $correctIndex) ? $answer : rand(2, 20);
            $buttons[] = ['text' => (string)$val, 'callback_data' => "captcha_{$userId}_{$val}"];
        }

        $options = [
            'reply_markup' => json_encode([
                'inline_keyboard' => [array_slice($buttons, 0, 2), array_slice($buttons, 2, 2)]
            ])
        ];

        $sent = $bot->sendMessage($chatId, $text, $options);
        
        // حفظ الإجابة في قاعدة البيانات
        $this->db->query("INSERT OR REPLACE INTO captcha (user_id, group_id, answer, message_id) VALUES (?, ?, ?, ?)", [
            $userId, $chatId, $answer, $sent['result']['message_id']
        ]);
        
        return $sent;
    }
}
