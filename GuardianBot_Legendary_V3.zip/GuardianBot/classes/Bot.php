<?php

require_once __DIR__ . '/../handlers/filters.php';
require_once __DIR__ . '/../handlers/admin.php';
require_once __DIR__ . '/../handlers/points.php';
require_once __DIR__ . '/../handlers/welcome.php';
require_once __DIR__ . '/../handlers/ai.php';
require_once __DIR__ . '/../handlers/moderation.php';
require_once __DIR__ . '/../handlers/control_panel.php';
require_once __DIR__ . '/../handlers/owner_info.php';

class Bot {
    private $token;
    private $apiUrl;
    private $db;
    private $security;

    public function __construct($token) {
        $this->token = $token;
        $this->apiUrl = "https://api.telegram.org/bot{$token}/";
        
        $config = require __DIR__ . '/../config.php';
        $this->db = new Database($config['database']);
        $this->security = new Security($this->db);
    }

    public function makeRequest($method, $params = []) {
        $ch = curl_init($this->apiUrl . $method);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    public function sendMessage($chatId, $text, $options = []) {
        $params = array_merge([
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML'
        ], $options);
        return $this->makeRequest('sendMessage', $params);
    }

    public function sendPhoto($chatId, $photo, $caption = "", $options = []) {
        $params = array_merge([
            'chat_id' => $chatId,
            'photo' => $photo,
            'caption' => $caption,
            'parse_mode' => 'HTML'
        ], $options);
        return $this->makeRequest('sendPhoto', $params);
    }

    public function deleteMessage($chatId, $messageId) {
        return $this->makeRequest('deleteMessage', [
            'chat_id' => $chatId,
            'message_id' => $messageId
        ]);
    }

    public function handleUpdate($update) {
        // معالجة ضغطات الأزرار (Callbacks)
        if (isset($update['callback_query'])) {
            $userId = $update['callback_query']['from']['id'];
            $chatId = $update['callback_query']['message']['chat']['id'];
            $chatMember = $this->makeRequest('getChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
            $rank = $chatMember['result']['status'] ?? 'member';

            if (handleCaptchaCallback($this, $update, $this->db)) return;
            if (handleAdminCallbacks($this, $update, $this->db, $rank)) return;
            if (handleControlPanel($this, $update, $this->db, $rank)) return;
        }

        if (isset($update['message'])) {
            $message = $update['message'];
            $chatId = $message['chat']['id'];
            $userId = $message['from']['id'];
            $text = $message['text'] ?? '';

            // 1. تسجيل المستخدم
            $this->db->query("INSERT OR IGNORE INTO users (id, first_name, username) VALUES (?, ?, ?)", [
                $userId, $message['from']['first_name'], $message['from']['username'] ?? null
            ]);

            $group = new Group($this->db, $chatId);
            $settings = $group->getSettings();
            $chatMember = $this->makeRequest('getChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
            $rank = $chatMember['result']['status'] ?? 'member';

            // 2. معالجة الأعضاء الجدد والكابتشا
            if (isset($message['new_chat_members'])) {
                foreach ($message['new_chat_members'] as $member) {
                    // تقييد العضو الجديد حتى يحل الكابتشا
                    $this->makeRequest('restrictChatMember', [
                        'chat_id' => $chatId,
                        'user_id' => $member['id'],
                        'permissions' => json_encode(['can_send_messages' => false])
                    ]);
                    $this->security->generateCaptcha($this, $chatId, $member['id'], $member['first_name']);
                }
                return;
            }

            // 3. فلاتر الحماية ومكافحة الفلود (للأعضاء فقط)
            if ($rank === 'member') {
                // مكافحة الفلود
                if ($settings['lock_spam'] && $this->security->isFlooding($userId)) {
                    $this->deleteMessage($chatId, $message['message_id']);
                    $user = new User($this->db, $userId, $chatId);
                    $warnCount = $user->addWarning("إرسال رسائل سريعة (فلود)");
                    
                    if ($warnCount >= 3) {
                        $this->makeRequest('restrictChatMember', ['chat_id' => $chatId, 'user_id' => $userId, 'until_date' => time() + 3600]);
                        $this->sendMessage($chatId, "🚫 تم كتم المستخدم <b>{$message['from']['first_name']}</b> لمدة ساعة لتكرار الفلود.");
                        $user->resetWarnings();
                    } else {
                        $this->sendMessage($chatId, "⚠️ توقف عن الفلود! إنذار ({$warnCount}/3)");
                    }
                    return;
                }

                if (handleFilters($this, $update, $settings)) return;
            }

            // 4. لوحة التحكم وأوامر الإدارة والنقاط
            if (handleControlPanel($this, $update, $this->db, $rank)) return;
            if (handleOwnerInfo($this, $update)) return;
            if (handleAdminCommands($this, $update, $rank)) return;
            if (handlePoints($this, $update, $this->db)) return;
        }
    }
}
