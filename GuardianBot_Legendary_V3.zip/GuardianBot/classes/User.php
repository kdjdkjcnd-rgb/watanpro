<?php

class User {
    private $db;
    private $id;
    private $groupId;

    public function __construct($db, $id, $groupId = null) {
        $this->db = $db;
        $this->id = $id;
        $this->groupId = $groupId;
    }

    public function getInfo() {
        return $this->db->fetch("SELECT * FROM users WHERE id = ?", [$this->id]);
    }

    public function updatePoints($amount) {
        $this->db->query("UPDATE users SET points = points + ? WHERE id = ?", [$amount, $this->id]);
    }

    public function addWarning($reason = "مخالفة القوانين") {
        if (!$this->groupId) return 0;
        
        $exists = $this->db->fetch("SELECT count FROM warnings WHERE user_id = ? AND group_id = ?", [$this->id, $this->groupId]);
        
        if ($exists) {
            $this->db->query("UPDATE warnings SET count = count + 1, last_reason = ? WHERE user_id = ? AND group_id = ?", [$reason, $this->id, $this->groupId]);
            $count = $exists['count'] + 1;
        } else {
            $this->db->query("INSERT INTO warnings (user_id, group_id, count, last_reason) VALUES (?, ?, 1, ?)", [$this->id, $this->groupId, $reason]);
            $count = 1;
        }
        
        return $count;
    }

    public function resetWarnings() {
        $this->db->query("DELETE FROM warnings WHERE user_id = ? AND group_id = ?", [$this->id, $this->groupId]);
    }

    public function getWarningCount() {
        $data = $this->db->fetch("SELECT count FROM warnings WHERE user_id = ? AND group_id = ?", [$this->id, $this->groupId]);
        return $data ? $data['count'] : 0;
    }
}
