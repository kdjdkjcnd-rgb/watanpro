<?php

class Group {
    private $db;
    private $id;

    public function __construct($db, $id) {
        $this->db = $db;
        $this->id = $id;
    }

    public function getSettings() {
        $group = $this->db->fetch("SELECT settings FROM groups WHERE id = ?", [$this->id]);
        return $group ? json_decode($group['settings'], true) : $this->getDefaultSettings();
    }

    public function updateSetting($key, $value) {
        $settings = $this->getSettings();
        $settings[$key] = $value;
        $json = json_encode($settings);
        
        $exists = $this->db->fetch("SELECT id FROM groups WHERE id = ?", [$this->id]);
        if ($exists) {
            $this->db->query("UPDATE groups SET settings = ? WHERE id = ?", [$json, $this->id]);
        } else {
            $this->db->query("INSERT INTO groups (id, settings) VALUES (?, ?)", [$this->id, $json]);
        }
    }

    private function getDefaultSettings() {
        return [
            'lock_links' => false,
            'lock_photos' => false,
            'lock_spam' => true,
            'welcome_msg' => "أهلاً بك {name} في المجموعة!",
            'protection_level' => 'medium'
        ];
    }
}
