<?php

class Database {
    private $pdo;

    public function __construct($config) {
        if ($config['type'] === 'sqlite') {
            $this->pdo = new PDO("sqlite:" . $config['sqlite_path']);
        } else {
            $dsn = "mysql:host={$config['mysql']['host']};dbname={$config['mysql']['dbname']};charset=utf8mb4";
            $this->pdo = new PDO($dsn, $config['mysql']['username'], $config['mysql']['password']);
        }
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->initialize();
    }

    private function initialize() {
        // إنشاء الجداول إذا لم تكن موجودة
        $queries = [
            "CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                points INTEGER DEFAULT 0,
                warnings INTEGER DEFAULT 0,
                rank TEXT DEFAULT 'member',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )",
            "CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY,
                title TEXT,
                settings TEXT,
                status TEXT DEFAULT 'active'
            )",
            "CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                user_id INTEGER,
                action TEXT,
                details TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )",
            "CREATE TABLE IF NOT EXISTS captcha (
                user_id INTEGER,
                group_id INTEGER,
                answer TEXT,
                message_id INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, group_id)
            )",
            "CREATE TABLE IF NOT EXISTS warnings (
                user_id INTEGER,
                group_id INTEGER,
                count INTEGER DEFAULT 0,
                last_reason TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, group_id)
            )"
        ];

        foreach ($queries as $query) {
            $this->pdo->exec($query);
        }
    }

    public function query($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function fetch($sql, $params = []) {
        return $this->query($sql, $params)->fetch();
    }

    public function fetchAll($sql, $params = []) {
        return $this->query($sql, $params)->fetchAll();
    }
}
