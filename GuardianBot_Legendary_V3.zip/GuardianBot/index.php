<?php

/**
 * Telegram Guardian Bot - Main Entry Point
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/helpers.php';

// تحميل الكلاسات تلقائياً
spl_autoload_register(function ($class_name) {
    $file = __DIR__ . '/classes/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

$config = require __DIR__ . '/config.php';

// التحقق من نوع الطلب (Webhook أو Long Polling)
$input = file_get_contents('php://input');
$update = json_decode($input, true);

if (!$update) {
    // إذا لم يكن هناك إدخال، قد يكون تشغيل عبر الـ CLI لـ Long Polling
    echo "Telegram Guardian Bot is running...\n";
    exit;
}

// معالجة التحديث
$bot = new Bot($config['bot_token']);
$bot->handleUpdate($update);
