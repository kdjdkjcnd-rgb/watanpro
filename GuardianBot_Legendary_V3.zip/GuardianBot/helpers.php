<?php

/**
 * Helper functions for Guardian Bot
 */

function format_user_mention($user) {
    $name = htmlspecialchars($user['first_name'] ?? 'مستخدم');
    $id = $user['id'];
    return "<a href='tg://user?id={$id}'>{$name}</a>";
}

function clean_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}
